<table class="table table-striped">
  <thead>

    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Price</th>
      <th scope="col">Qty</th>
    </tr>
  </thead>
  <tbody>
    <?php $i=1 ; ?>
        <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
      <th scope="row"><?php echo e($i++); ?></th>
      <td><?php echo e($product['name']); ?></td>
      <td><?php echo e($product['price']); ?></td>
      <td><?php echo e($product['qty']); ?></td>
    </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br>
        Total Price:<?php echo e($cart->totalPrice); ?>

        Plese click the link to view your order.<a href="<?php echo e(url('/orders')); ?>"> click here</a>

    
  </tbody>
</table><?php /**PATH C:\Users\upgam\OneDrive\เอกสาร\GitHub\myproject\resources\views/emails/mail.blade.php ENDPATH**/ ?>