

<?php $__env->startSection('content'); ?>

 <div class="container">
 	
 	<div class="row justify-content-center">
	 
 		<div class="col-md-8">
		 <a class="fas fa-arrow-left" href="/orders"> ย้อนกลับ</a>
 			<?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 			<div class="card mb-3">
 				<div class="card-body">
 					<?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 					<span class="float-right">
 						<img src="<?php echo e(Storage::url($item['image'])); ?>" width="100" height="100">
 					</span>

 					<p>ชื่อสินค้า:<?php echo e($item['name']); ?></p>
 					<p>ราคา:<?php echo e($item['price']); ?></p>
 					<p>จำนวณ:<?php echo e($item['qty']); ?></p>

 					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 					
 				</div>
			
 				  
				   <div class="card-body row">
			  
					  <div class="col"> <strong>ราคารวม: <?php echo e($cart->totalPrice); ?>  ฿</div>
					  
				  </div>
				 
 			</div>
 			
		
 			
 			<hr>
 			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 		</div>
 	</div>
 	


 </div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\upgam\OneDrive\เอกสาร\GitHub\myproject\resources\views/orderuser.blade.php ENDPATH**/ ?>