
<?php $__env->startSection('content'); ?>
<?php echo e(csrf_field()); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 ml-4 text-gray-800">Company</h1>
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page">Company</li>
  </ol>
</div>
<div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            
          </div>

          <div class="row">
            <div class="col-lg-12 mb-4">
              <!-- Simple Tables -->
              <div class="card">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                 <a class="m-0 font-weight-bold text-primary" href="company/create">company create</a>
                </div>
                <div class="table-responsive">
                  <table class="table align-items-center table-flush">
                    <thead class="thead-light">
                      <tr>
                        <th>#</th>
                        <th>company_name</th>
                        <th>action</th>
                        <th></th>
                      </tr>
                    </thead>
                    <?php if(count($company)>0): ?>
                    <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                      <tr>
                        <td><?php echo e($row->id); ?></td>
                        <td><?php echo e($row->company_name); ?></td>

                        <td><a href="<?php echo e(route('company.edit',[$row->id])); ?>" class="btn btn-sm btn-primary">Edit</a></td>
                        <td>
                        <form action="<?php echo e(route('company.destroy',$row->id)); ?>"method="post"><?php echo csrf_field(); ?> 
                        <?php echo e(method_field('DELETE')); ?>

                        <input type="submit" value="delete"class="btn btn-danger" onclick=" return confirm('u want delete ? id <?php echo e($row->id); ?> <?php echo e($row->name); ?>') ">
                        </form>
                        </td>
                      </tr>
                    
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                      <td>No category created yet!</td>
                    <?php endif; ?>
                  </table>
                  
                </div>
                
                <div class="card-footer"></div>
              </div>
            </div>
            
          </div>
          <!--Row-->
        </div>
        <!---Container Fluid-->
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\upgam\OneDrive\เอกสาร\GitHub\myproject\resources\views/admin/company/index.blade.php ENDPATH**/ ?>