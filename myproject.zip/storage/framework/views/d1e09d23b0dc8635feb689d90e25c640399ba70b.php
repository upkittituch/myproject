<footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>copyright &copy; 2020 - developed by
              <b><a href="https://github.com/upkittituch/myproject" target="_blank">kittituch</a></b>
            </span>
          </div>
        </div>
        
        
</footer>
      
  <script src="<?php echo e(asset('admin/vendor/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/js/ruang-admin.min.js')); ?>"></script>
  <!-- <script src="<?php echo e(asset('admin/vendor/chart.js/Chart.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/js/demo/chart-area-demo.js')); ?>"></script>   --><?php /**PATH C:\Users\upgam\OneDrive\เอกสาร\GitHub\myproject\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>