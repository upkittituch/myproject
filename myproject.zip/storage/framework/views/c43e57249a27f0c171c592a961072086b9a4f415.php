<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\upgam\OneDrive\เอกสาร\GitHub\myproject\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>