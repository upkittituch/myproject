

<?php $__env->startSection('content'); ?>
 
    <div class="row justify-content-center">
   

      <div class="col-lg-10">
      <a class="fas fa-arrow-left" href="<?php echo e(route('order.index')); ?>"> ย้อนกลับ</a>
        <form action="<?php echo e(route('payment.update',[$orders->user_id,$orders->id])); ?>" method="POST" enctype="multipart/form-data"><?php echo csrf_field(); ?>
        	<?php echo e(method_field('PUT')); ?>  <?php echo csrf_field(); ?>

              <div class="card mb-6">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">edit</h6>
                </div>
                <div class="card-body">
                    <div class="form-group"> 
                      <label for="">payment</label>

                          <select name="payment" id="payment">
                            <option value="<?php echo e($orders->payment); ?>"><?php echo e($orders->payment); ?></option>
                            <option value="success">success</option>
                            <option value="cancel">cancel</option>
                          </select>
                     
                    </div>
                    
                    <br>   
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
              </div>
            </form>

          </div>
          
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\upgam\OneDrive\เอกสาร\GitHub\myproject\resources\views/admin/order/payment.blade.php ENDPATH**/ ?>